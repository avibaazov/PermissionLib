package com.classy.permissionlib;

import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PermissionGroupInfo;
import android.content.pm.PermissionInfo;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.Arrays;
import java.util.List;

public class SystemIconRationaleDialog extends Dialog {

    private final List<String> deniedPermissions;
    private Runnable onPositiveClick;
    private Runnable onNegativeClick;

    public SystemIconRationaleDialog(@NonNull Context context, String[] deniedPermissions) {
        // Use the dialog-specific theme (make sure the style name matches your resources)
        super(context, R.style.Theme_PermissionLib_Dialog);
        this.deniedPermissions = Arrays.asList(deniedPermissions);
    }

    public void setOnPositiveClick(Runnable onPositiveClick) {
        this.onPositiveClick = onPositiveClick;
    }

    public void setOnNegativeClick(Runnable onNegativeClick) {
        this.onNegativeClick = onNegativeClick;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflate the PermissionX‑style layout (dialog_permissionx_style.xml)
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_improved_custom, null);
        setContentView(view);

        // Set the main message text
        TextView messageText = view.findViewById(R.id.messageText);
        messageText.setText("The following permissions are required:");

        // Get the container for permission items
        LinearLayout container = view.findViewById(R.id.permissionsLayout);
        LayoutInflater inflater = LayoutInflater.from(getContext());
        PackageManager packageManager = getContext().getPackageManager();

        // For each denied permission, inflate an item view and set its icon and text
        for (String permission : deniedPermissions) {
            View itemView = inflater.inflate(R.layout.item_permission, container, false);
            ImageView iconView = itemView.findViewById(R.id.permission_icon);
            TextView permissionText = itemView.findViewById(R.id.permission_text);

            try {
                PermissionInfo pInfo = packageManager.getPermissionInfo(permission, 0);
                if (pInfo.group != null) {
                    PermissionGroupInfo pgInfo = packageManager.getPermissionGroupInfo(pInfo.group, 0);
                    if (pgInfo.labelRes != 0) {
                        permissionText.setText(getContext().getString(pgInfo.labelRes));
                    } else {
                        permissionText.setText(permission.replace("android.permission.", "").replace("_", " "));
                    }
                    iconView.setImageResource(pgInfo.icon);
                } else {
                    permissionText.setText(permission.replace("android.permission.", "").replace("_", " "));
                    iconView.setImageResource(android.R.drawable.ic_dialog_info);
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
                permissionText.setText(permission.replace("android.permission.", "").replace("_", " "));
                iconView.setImageResource(android.R.drawable.ic_dialog_info);
            }
            container.addView(itemView);
        }

        // Set up the positive and negative buttons
        Button positiveBtn = view.findViewById(R.id.positiveBtn);
        Button negativeBtn = view.findViewById(R.id.negativeBtn);

        positiveBtn.setOnClickListener(v -> {
            dismiss();
            if (onPositiveClick != null) {
                onPositiveClick.run();
            }
        });

        negativeBtn.setOnClickListener(v -> {
            dismiss();
            if (onNegativeClick != null) {
                onNegativeClick.run();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Adjust the dialog window size to be smaller (e.g., 85% of screen width)
        if (getWindow() != null) {
            DisplayMetrics dm = getContext().getResources().getDisplayMetrics();
            int width = (int) (dm.widthPixels * 0.85);
            getWindow().setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT);
        }
    }
}
