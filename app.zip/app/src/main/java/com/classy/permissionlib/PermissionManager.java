//package com.classy.permissionlib;
//
//import android.content.Context;
//import android.content.Intent;
//import android.content.pm.PackageManager;
//import android.net.Uri;
//import android.provider.Settings;
//
//import androidx.activity.result.ActivityResultLauncher;
//import androidx.activity.result.contract.ActivityResultContracts;
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//import androidx.lifecycle.DefaultLifecycleObserver;
//import androidx.lifecycle.LifecycleOwner;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
///**
// * PermissionManager provides a fluent API to request permissions.
// * It handles the request flow internally using an ActivityResultLauncher and
// * automatically re-checks permissions when returning from settings.
// */
//public class PermissionManager {
//
//    // Callback interfaces are defined in separate files.
//    // (OnExplainRequestReasonCallback, OnForwardToSettingsCallback, PermissionResultCallback)
//
//    // -------------------------------
//    // Builder Class for Chainable API.
//    // -------------------------------
//    public static class Builder {
//        private final AppCompatActivity activity;
//        private String[] permissions;
//        private OnExplainRequestReasonCallback explainCallback;
//        private OnForwardToSettingsCallback forwardCallback;
//        private PermissionResultCallback resultCallback;
//        private boolean explainBeforeRequest = false;
//
//        public Builder(AppCompatActivity activity) {
//            this.activity = activity;
//        }
//
//        public Builder permissions(String... permissions) {
//            if (permissions == null || permissions.length == 0) {
//                throw new IllegalArgumentException("You must provide at least one permission");
//            }
//            this.permissions = permissions;
//            return this;
//        }
//
//        public Builder explainReasonBeforeRequest() {
//            this.explainBeforeRequest = true;
//            return this;
//        }
//
//        public Builder onExplainRequestReason(OnExplainRequestReasonCallback callback) {
//            this.explainCallback = callback;
//            return this;
//        }
//
//        public Builder onForwardToSettings(OnForwardToSettingsCallback callback) {
//            this.forwardCallback = callback;
//            return this;
//        }
//
//        public void request(PermissionResultCallback callback) {
//            if (callback == null) {
//                throw new IllegalArgumentException("PermissionResultCallback cannot be null");
//            }
//            this.resultCallback = callback;
//            PermissionManager pm = new PermissionManager(activity, permissions, explainCallback,
//                    forwardCallback, resultCallback, explainBeforeRequest);
//            pm.requestPermissions();
//        }
//    }
//
//    public static Builder init(AppCompatActivity activity) {
//        return new Builder(activity);
//    }
//
//    // -------------------------------
//    // Instance Fields.
//    // -------------------------------
//    private final AppCompatActivity activity;
//    private final String[] permissions;
//    private final OnExplainRequestReasonCallback explainCallback;
//    private final OnForwardToSettingsCallback forwardCallback;
//    private final PermissionResultCallback resultCallback;
//    private final boolean explainBeforeRequest;
//    private final ActivityResultLauncher<String[]> permissionLauncher;
//    // Flag to ensure explanation is shown only once per permission cycle.
//    private boolean hasShownExplanation = false;
//    // Flag to indicate that the user has been forwarded to settings.
//    private boolean waitingForSettingsResult = false;
//
//    private PermissionManager(AppCompatActivity activity, String[] permissions,
//                              OnExplainRequestReasonCallback explainCallback,
//                              OnForwardToSettingsCallback forwardCallback,
//                              PermissionResultCallback resultCallback,
//                              boolean explainBeforeRequest) {
//        this.activity = activity;
//        this.permissions = permissions;
//        this.explainCallback = explainCallback;
//        this.forwardCallback = forwardCallback;
//        this.resultCallback = resultCallback;
//        this.explainBeforeRequest = explainBeforeRequest;
//        // Register the ActivityResultLauncher once during construction.
//        permissionLauncher = activity.registerForActivityResult(
//                new ActivityResultContracts.RequestMultiplePermissions(),
//                this::handlePermissionResult
//        );
//        // Register a lifecycle observer to re-check permissions when resuming.
//        if (activity instanceof LifecycleOwner) {
//            ((LifecycleOwner) activity).getLifecycle().addObserver(new DefaultLifecycleObserver() {
//                @Override
//                public void onResume(@NonNull LifecycleOwner owner) {
//                    // If the user was forwarded to settings, check the permission state upon resume.
//                    if (waitingForSettingsResult) {
//                        checkCurrentPermissionsAndCallback();
//                    }
//                }
//            });
//        }
//    }
//
//    // -------------------------------
//    // Permission Request Flow.
//    // -------------------------------
//    private void requestPermissions() {
//        if (arePermissionsGranted(activity, permissions)) {
//            resultCallback.onResult(true, permissions, new String[0]);
//            return;
//        }
//        // If forced explanation is enabled and it hasn't been shown, show it first.
//        if (explainBeforeRequest && explainCallback != null && !hasShownExplanation) {
//            String[] denied = getDeniedPermissions(activity, permissions);
//            hasShownExplanation = true;
//            explainCallback.onExplain(denied, () -> {
//                // Reset the flag before re-launching.
//                hasShownExplanation = false;
//                permissionLauncher.launch(permissions);
//            });
//        } else {
//            // Launch the permission request directly.
//            permissionLauncher.launch(permissions);
//        }
//    }
//
//    private void handlePermissionResult(Map<String, Boolean> result) {
//        List<String> grantedList = new ArrayList<>();
//        List<String> deniedList = new ArrayList<>();
//        List<String> permanentlyDeniedList = new ArrayList<>();
//
//        for (String permission : permissions) {
//            Boolean granted = result.get(permission);
//            if (granted != null && granted) {
//                grantedList.add(permission);
//            } else {
//                deniedList.add(permission);
//                // If no rationale can be shown, treat it as permanently denied.
//                if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
//                    permanentlyDeniedList.add(permission);
//                }
//            }
//        }
//
//        boolean allGranted = grantedList.size() == permissions.length;
//
//        // If any permissions are permanently denied, trigger the forward-to-settings callback.
//        if (!allGranted && !permanentlyDeniedList.isEmpty() && forwardCallback != null) {
//            waitingForSettingsResult = true; // Mark that we are waiting for the settings result.
//            forwardCallback.onForward(permanentlyDeniedList.toArray(new String[0]), this::openAppSettings);
//        } else {
//            // If not all granted and explanation hasn't been shown, try showing it.
//            if (!allGranted && !hasShownExplanation && explainCallback != null) {
//                String[] denied = getDeniedPermissions(activity, permissions);
//                hasShownExplanation = true;
//                explainCallback.onExplain(denied, () -> {
//                    hasShownExplanation = false;
//                    permissionLauncher.launch(permissions);
//                });
//                return; // Wait for the user's response before calling the final result.
//            }
//            resultCallback.onResult(allGranted,
//                    grantedList.toArray(new String[0]),
//                    deniedList.toArray(new String[0]));
//            hasShownExplanation = false;
//        }
//    }
//
//    // -------------------------------
//    // New Helper: Check Current Permissions and Callback.
//    // -------------------------------
//    /**
//     * Re-checks the permission status and calls the result callback.
//     * This is used when returning from settings.
//     */
//    private void checkCurrentPermissionsAndCallback() {
//        List<String> grantedList = new ArrayList<>();
//        List<String> deniedList = new ArrayList<>();
//        for (String permission : permissions) {
//            if (ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED) {
//                grantedList.add(permission);
//            } else {
//                deniedList.add(permission);
//            }
//        }
//        boolean allGranted = grantedList.size() == permissions.length;
//        waitingForSettingsResult = false; // Reset the flag after checking.
//        resultCallback.onResult(allGranted,
//                grantedList.toArray(new String[0]),
//                deniedList.toArray(new String[0]));
//    }
//
//    // -------------------------------
//    // Helper Methods.
//    // -------------------------------
//    private static boolean arePermissionsGranted(Context context, String[] permissions) {
//        for (String permission : permissions) {
//            if (ContextCompat.checkSelfPermission(context, permission)
//                    != PackageManager.PERMISSION_GRANTED) {
//                return false;
//            }
//        }
//        return true;
//    }
//
//    private static String[] getDeniedPermissions(Context context, String[] permissions) {
//        List<String> denied = new ArrayList<>();
//        for (String permission : permissions) {
//            if (ContextCompat.checkSelfPermission(context, permission)
//                    != PackageManager.PERMISSION_GRANTED) {
//                denied.add(permission);
//            }
//        }
//        return denied.toArray(new String[0]);
//    }
//
//    public static void openAppSettings(AppCompatActivity activity) {
//        try {
//            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
//            Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
//            intent.setData(uri);
//            activity.startActivity(intent);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void openAppSettings() {
//        openAppSettings(activity);
//    }
//}
package com.classy.permissionlib;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PermissionManager {

    public interface PermissionResultCallback {
        void onResult(boolean allGranted, String[] grantedPermissions, String[] deniedPermissions);
    }

    public interface OnExplainRequestReasonCallback {
        void onExplain(String[] deniedPermissions, Runnable continueRequest);
    }

    public interface OnForwardToSettingsCallback {
        void onForward(String[] permanentlyDeniedPermissions, Runnable openSettings);
    }

    // -------------------------------
    // Builder for the Chainable API.
    // -------------------------------
    public static class Builder {
        private final AppCompatActivity activity;
        private String[] permissions;
        private OnExplainRequestReasonCallback explainCallback;
        private OnForwardToSettingsCallback forwardCallback;
        private PermissionResultCallback resultCallback;
        private boolean explainBeforeRequest = false;

        public Builder(AppCompatActivity activity) {
            this.activity = activity;
        }

        public Builder permissions(String... permissions) {
            if (permissions == null || permissions.length == 0) {
                throw new IllegalArgumentException("You must provide at least one permission");
            }
            this.permissions = permissions;
            return this;
        }

        public Builder explainReasonBeforeRequest() {
            this.explainBeforeRequest = true;
            return this;
        }

        public Builder onExplainRequestReason(OnExplainRequestReasonCallback callback) {
            this.explainCallback = callback;
            return this;
        }

        public Builder onForwardToSettings(OnForwardToSettingsCallback callback) {
            this.forwardCallback = callback;
            return this;
        }

        public void request(PermissionResultCallback callback) {
            if (callback == null) {
                throw new IllegalArgumentException("PermissionResultCallback cannot be null");
            }
            this.resultCallback = callback;
            PermissionManager pm = new PermissionManager(activity, permissions, explainCallback,
                    forwardCallback, resultCallback, explainBeforeRequest);
            pm.requestPermissions();
        }
    }

    public static Builder init(AppCompatActivity activity) {
        return new Builder(activity);
    }

    // -------------------------------
    // Instance Fields.
    // -------------------------------
    private final AppCompatActivity activity;
    private final String[] permissions;
    private final OnExplainRequestReasonCallback explainCallback;
    private final OnForwardToSettingsCallback forwardCallback;
    private final PermissionResultCallback resultCallback;
    private final boolean explainBeforeRequest;
    private final ActivityResultLauncher<String[]> permissionLauncher;
    private boolean hasShownExplanation = false;
    private boolean waitingForSettingsResult = false;

    private PermissionManager(AppCompatActivity activity, String[] permissions,
                              OnExplainRequestReasonCallback explainCallback,
                              OnForwardToSettingsCallback forwardCallback,
                              PermissionResultCallback resultCallback,
                              boolean explainBeforeRequest) {
        this.activity = activity;
        this.permissions = permissions;
        this.explainCallback = explainCallback;
        this.forwardCallback = forwardCallback;
        this.resultCallback = resultCallback;
        this.explainBeforeRequest = explainBeforeRequest;

        permissionLauncher = activity.registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                this::handlePermissionResult
        );

        if (activity instanceof LifecycleOwner) {
            ((LifecycleOwner) activity).getLifecycle().addObserver(new DefaultLifecycleObserver() {
                @Override
                public void onResume(@NonNull androidx.lifecycle.LifecycleOwner owner) {
                    if (waitingForSettingsResult) {
                        checkCurrentPermissionsAndCallback();
                    }
                }
            });
        }
    }

    private void requestPermissions() {
        if (arePermissionsGranted(activity, permissions)) {
            resultCallback.onResult(true, permissions, new String[0]);
            return;
        }
        if (explainBeforeRequest && !hasShownExplanation) {
            String[] denied = getDeniedPermissions(activity, permissions);
            hasShownExplanation = true;
            if (explainCallback != null) {
                explainCallback.onExplain(denied, () -> {
                    hasShownExplanation = false;
                    permissionLauncher.launch(permissions);
                });
            } else {
//                // Use the improved custom dialog if no custom explanation is provided.
//                ImprovedCustomDialog dialog = new ImprovedCustomDialog(activity, denied);
//                dialog.setOnPositiveListener(() -> {
//                    hasShownExplanation = false;
//                    permissionLauncher.launch(permissions);
//                });
//                dialog.setOnNegativeListener(() -> {
//                    // Optionally, report cancellation.
//                    resultCallback.onResult(false, new String[0], denied);
//                });
//                dialog.show();
                SystemIconRationaleDialog dialog = new SystemIconRationaleDialog(activity, denied);
                dialog.setOnPositiveClick(() -> {
                    hasShownExplanation = false;
                    permissionLauncher.launch(permissions);
                });
                dialog.setOnNegativeClick(() -> {
                    // Optionally, report cancellation.
                    resultCallback.onResult(false, new String[0], denied);
                });
                dialog.show();
            }
        } else {
            permissionLauncher.launch(permissions);
        }
    }

    private void handlePermissionResult(Map<String, Boolean> result) {
        List<String> grantedList = new ArrayList<>();
        List<String> deniedList = new ArrayList<>();
        List<String> permanentlyDeniedList = new ArrayList<>();

        for (String permission : permissions) {
            Boolean granted = result.get(permission);
            if (granted != null && granted) {
                grantedList.add(permission);
            } else {
                deniedList.add(permission);
                if (!ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)) {
                    permanentlyDeniedList.add(permission);
                }
            }
        }

        boolean allGranted = grantedList.size() == permissions.length;

        if (!allGranted && !permanentlyDeniedList.isEmpty()) {
            waitingForSettingsResult = true;
            if (forwardCallback != null) {
                forwardCallback.onForward(permanentlyDeniedList.toArray(new String[0]), this::openAppSettings);
            } else {
                // Show a simple dialog forwarding user to settings.
                new android.app.AlertDialog.Builder(activity)
                        .setTitle("Permissions Permanently Denied")
                        .setMessage("Some permissions have been permanently denied.\nPlease open app settings to grant them.")
                        .setPositiveButton("Open Settings", (dialog, which) -> openAppSettings())
                        .setNegativeButton("Cancel", null)
                        .setCancelable(false)
                        .show();
            }
        } else {
            if (!allGranted && !hasShownExplanation && explainCallback != null) {
                String[] denied = getDeniedPermissions(activity, permissions);
                hasShownExplanation = true;
                explainCallback.onExplain(denied, () -> {
                    hasShownExplanation = false;
                    permissionLauncher.launch(permissions);
                });
                return;
            }
            resultCallback.onResult(allGranted,
                    grantedList.toArray(new String[0]),
                    deniedList.toArray(new String[0]));
            hasShownExplanation = false;
        }
    }

    private void checkCurrentPermissionsAndCallback() {
        List<String> grantedList = new ArrayList<>();
        List<String> deniedList = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED) {
                grantedList.add(permission);
            } else {
                deniedList.add(permission);
            }
        }
        boolean allGranted = grantedList.size() == permissions.length;
        waitingForSettingsResult = false;
        resultCallback.onResult(allGranted,
                grantedList.toArray(new String[0]),
                deniedList.toArray(new String[0]));
    }

    private static boolean arePermissionsGranted(Context context, String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private static String[] getDeniedPermissions(Context context, String[] permissions) {
        List<String> denied = new ArrayList<>();
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(context, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                denied.add(permission);
            }
        }
        return denied.toArray(new String[0]);
    }

    public static void openAppSettings(AppCompatActivity activity) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            Uri uri = Uri.fromParts("package", activity.getPackageName(), null);
            intent.setData(uri);
            activity.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openAppSettings() {
        openAppSettings(activity);
    }
}
