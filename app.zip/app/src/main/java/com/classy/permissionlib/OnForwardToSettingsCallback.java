package com.classy.permissionlib;

import androidx.annotation.NonNull;
import java.util.List;


/**
 * Callback to handle permanently denied permissions.
 */
public interface OnForwardToSettingsCallback {
    /**
     * Called when some permissions are permanently denied.
     *

     * @param permanentlyDeniedPermissions The list of permanently denied permissions.
     */
    void onForward(String[] permanentlyDeniedPermissions, Runnable openSettings);
}
