package com.classy.permissionlib;

import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Determine the appropriate storage permission based on API level.
        String storagePermission = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;

        // Use the builder API to request permissions.
        PermissionManager.init(this)
                .permissions(storagePermission, Manifest.permission.CAMERA, Manifest.permission.READ_SMS)
                // Force showing the rationale on subsequent requests.

                .onExplainRequestReason((deniedPermissions, continueRequest) -> {

                    SystemIconRationaleDialog dialog = new SystemIconRationaleDialog(this, deniedPermissions);
                    dialog.setExplanationMessage("We need these permissions to allow you to capture and view photos, and to enhance app functionality.");
                    dialog.setOnPositiveClick(continueRequest);
                    dialog.setOnNegativeClick(() -> {
                        // Optionally handle negative
                    });
                    dialog.show();
                })
                .onForwardToSettings((permanentlyDeniedPermissions, openSettings) -> {
                    new androidx.appcompat.app.AlertDialog.Builder(this)
                            .setTitle("Permissions Permanently Denied")
                            .setMessage("These permissions are permanently denied: " + String.join(", ", permanentlyDeniedPermissions)
                                    + "\nPlease open app settings to grant them.")
                            .setPositiveButton("Open Settings", (dialog, which) -> openSettings.run())
                            .setNegativeButton("Cancel", null)
                            .show();
                })
                .request((allGranted, grantedPermissions, deniedPermissions) -> {
                    if (allGranted) {
                        Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Denied: " + String.join(", ", deniedPermissions), Toast.LENGTH_LONG).show();
                    }
                });
    }
}